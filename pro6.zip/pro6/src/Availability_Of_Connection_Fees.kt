import Mobile_communication_Operator.*
open class Availability_Of_Connection_Fees(var empname_operator:String,var empcost_of_conversation: Double,var empsquare:Double,var availability_of_payment: Boolean):Mobile_communication_Operator(empname_operator,empcost_of_conversation,empsquare) {
    override fun Q(): Double {
        if (availability_of_payment) {
            return 0.7 * 100 * empsquare / empcost_of_conversation
        } else {
            return 1.5 * 100 * empsquare / empcost_of_conversation
        }
    }

    open fun Payment() {
        if (availability_of_payment) {
            println("все оплачено")
        } else {
            println("оплатить? (y/n)")
            var c: String = readln()
            while (c != "y" && c != "n") {
                println("error")
                println("оплатить? (y/n)")
                c = readln()
            }
            when(c){
                "y" -> availability_of_payment = true
                "n" -> availability_of_payment = false
                else -> println("error")
            }
        }
    }
    override fun Info():String{
        return "Name operator: $empname_operator\nCost of conversation: $empcost_of_conversation\nSquare: $empsquare\nAvailability of payment: $availability_of_payment"
    }
}