import Mobile_communication_Operator.*
class Mobile_companies (var empname_operator:String,var empcost_of_conversation: Double,var cost_of_internet:Double,var cost_of_letters:Double,var empsquare:Double):Mobile_communication_Operator(empname_operator,empcost_of_conversation,empsquare) {
    override fun Cost(amount:Double){
        println("Cost of conversation: ${empcost_of_conversation*amount}\nCost of internet: ${cost_of_internet*amount}\nCost of letters: ${cost_of_letters*amount}");
    }
    override fun Q():Double{
        return 100*empsquare/(empcost_of_conversation*cost_of_internet*cost_of_letters)
    }
    override fun Info():String{
        return "Name operator: $empname_operator\nCost of conversation: $empcost_of_conversation\nCost of internet: $cost_of_internet\nCost of letters: $cost_of_letters\nSquare: $empsquare"
    }

}