import Mobile_communication_Operator.Mobile_communication_Operator as MobileCO
fun main() =try{
    var mobile_communication_operator1=MobileCO("mobile communication operator1.1",59.9,10000.0)
    var mobile_companiesr1=Mobile_companies("mobile companies1.1",89.9,199.9,209.9,2000.0)
    var availability_Of_Connection_Fees1 = Availability_Of_Connection_Fees("availability of connection fees1.1",99.9,1000.0,false)

    mobile_communication_operator1.Cost(1000.9)
    println(mobile_communication_operator1.Q())
    println(mobile_communication_operator1.Info())

    mobile_companiesr1.Cost(100.0)
    println(mobile_companiesr1.Q())
    println(mobile_companiesr1.Info())

    availability_Of_Connection_Fees1.Payment()
    println(availability_Of_Connection_Fees1.Q())
    println(availability_Of_Connection_Fees1.Info())
}
catch (e:NumberFormatException){println("error")}
