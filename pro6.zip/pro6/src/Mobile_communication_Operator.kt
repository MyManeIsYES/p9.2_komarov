package Mobile_communication_Operator
open class Mobile_communication_Operator(var name_operator: String,var cost_of_conversation: Double,var square: Double) {
    open fun Info():String{
      return "Name operator: $name_operator\nCost of conversation: $cost_of_conversation\nSquare: $square"
    }
    open fun Cost(amount:Double){
        println("Cost of conversation: ${cost_of_conversation*amount}");
    }

    open fun Q():Double{
        return 100*square/cost_of_conversation
    }

}
